# Example Python Code to Insert a Document

from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, username, password):
        # Connection Variables
        USER = username
        PASS = password
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        # Initialize Connection
        self.client = MongoClient(
            'mongodb://%s:%s@%s:%d/%s?authSource=admin'
            % (USER, PASS, HOST, PORT, DB)
        )

        # Database and Collection
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # CREATE (C in CRUD)
    def create(self, data):
        try:
            if data is not None:
                self.collection.insert_one(data)
                return True
            else:
                return False
        except Exception as e:
            print("Error:", e)
            return False

    # READ (R in CRUD)
    def read(self, query):
        try:
            result = self.collection.find(query)
            return list(result)
        except Exception as e:
            print("Error:", e)
            return []

    # UPDATE (U in CRUD)
    def update(self, query, new_values):
        try:
            if query is not None and new_values is not None:
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            else:
                return 0
        except Exception as e:
            print("Error:", e)
            return 0

    # DELETE (D in CRUD)
    def delete(self, query):
        try:
            if query is not None:
                result = self.collection.delete_many(query)
                return result.deleted_count
            else:
                return 0
        except Exception as e:
            print("Error:", e)
            return 0